
<html>
<body>
  <h1>Welcome Admin!</h1>
  <p>This is the admin page.</p>
  <a href="../login.html.php">Back to Login</a>
</body>
</html>
