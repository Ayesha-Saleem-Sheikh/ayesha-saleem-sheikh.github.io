<?php
session_start();

if (!isset($_SESSION['username']) || ($_SESSION['position'] ?? '') !== 'admin') {
    echo json_encode([
        'success' => false,
        'message' => 'Unauthorized'
    ]);
    exit;
}


if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method'
    ]);
    exit;
}

if (
    !isset($_POST['oldUsername']) ||
    !isset($_POST['newUsername']) ||
    !isset($_POST['newPassword'])
) {
    echo json_encode([
        'success' => false,
        'message' => 'Missing required fields'
    ]);
    exit;
}

$oldUsername = trim($_POST['oldUsername']);
$newUsername = trim($_POST['newUsername']);
$newPassword = trim($_POST['newPassword']);
$position    = $_POST['position'] ?? null; 


$users_path = __DIR__ . '/../User/users.json';

if (!file_exists($users_path)) {
    echo json_encode([
        'success' => false,
        'message' => 'Users file not found'
    ]);
    exit;
}

$json  = file_get_contents($users_path);
$users = json_decode($json, true);

if (!is_array($users)) {
    echo json_encode([
        'success' => false,
        'message' => 'Error reading users file'
    ]);
    exit;
}


$userFound = false;
$userIndex = -1;

for ($i = 0; $i < count($users); $i++) {
    if (isset($users[$i]['username']) && $users[$i]['username'] === $oldUsername) {
        $userFound = true;
        $userIndex = $i;
        break;
    }
}

if (!$userFound) {
    echo json_encode([
        'success' => false,
        'message' => 'User not found'
    ]);
    exit;
}


if ($oldUsername !== $newUsername && $newUsername !== '') {
    for ($i = 0; $i < count($users); $i++) {
        if ($i === $userIndex) continue; 
        if (isset($users[$i]['username']) && $users[$i]['username'] === $newUsername) {
            echo json_encode([
                'success' => false,
                'message' => 'Username already exists'
            ]);
            exit;
        }
    }
}


if ($newUsername !== '') {
    $users[$userIndex]['username'] = $newUsername;
}
if ($newPassword !== '') {
    $users[$userIndex]['password'] = $newPassword;
}
if ($position !== null && $position !== '') {
    $users[$userIndex]['position'] = $position;
}


$newJson = json_encode($users, JSON_PRETTY_PRINT);
if (file_put_contents($users_path, $newJson) === false) {
    echo json_encode([
        'success' => false,
        'message' => 'Error writing to users file'
    ]);
    exit;
}

echo json_encode([
    'success' => true,
    'message' => 'User updated successfully',
    'users'   => $users
]);
exit;