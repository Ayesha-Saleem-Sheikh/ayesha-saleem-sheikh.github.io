<?php
session_start();
header('Content-Type: application/json; charset=UTF-8');


if (!isset($_SESSION['username']) || ($_SESSION['position'] ?? '') !== 'admin') {
    echo json_encode([
        'success' => false,
        'message' => 'Unauthorized'
    ]);
    exit;
}


if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method'
    ]);
    exit;
}

if (!isset($_POST['username']) || trim($_POST['username']) === '') {
    echo json_encode([
        'success' => false,
        'message' => 'Username not provided'
    ]);
    exit;
}

$usernameToDelete = trim($_POST['username']);

$users_path = __DIR__ . '/../User/users.json';

if (!file_exists($users_path)) {
    echo json_encode([
        'success' => false,
        'message' => 'Users file not found'
    ]);
    exit;
}

$json = file_get_contents($users_path);
$users = json_decode($json, true);

if (!is_array($users)) {
    echo json_encode([
        'success' => false,
        'message' => 'Error reading users file'
    ]);
    exit;
}

$userFound = false;
$newUsers = [];

foreach ($users as $u) {
    if (isset($u['username']) && $u['username'] === $usernameToDelete) {
        $userFound = true;
        continue;
    }
    $newUsers[] = $u;
}

if (!$userFound) {
    echo json_encode([
        'success' => false,
        'message' => 'User not found'
    ]);
    exit;
}

$newJson = json_encode($newUsers, JSON_PRETTY_PRINT);
if (file_put_contents($users_path, $newJson) === false) {
    echo json_encode([
        'success' => false,
        'message' => 'Error writing to users file'
    ]);
    exit;
}


echo json_encode([
    'success' => true,
    'message' => 'User deleted successfully',
    'users'   => $newUsers
]);
exit;