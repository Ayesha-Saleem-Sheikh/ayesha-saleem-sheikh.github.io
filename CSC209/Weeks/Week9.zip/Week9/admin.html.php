<html>
<head>
</head>

<body>
<p id=table></p>

<?php

function decode(){
$myJson = file_get_contents("users.json");
$obj = json_decode($myJson,true);
$loopCount = count($obj);
foreach ($obj as $x => $y) {
    for ($i = 0; $i < $loopCount;$i++ ){
    echo '<table>
            <tr>
            <td>';
        echo $y[$i];
        echo '/td>';
}
  echo  '</tr>
         </table>';
}

}

decode();
?>

</body>

</html>
